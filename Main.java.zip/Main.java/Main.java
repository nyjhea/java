import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Hány autót szeretnél rögzíteni? ");
        int carCount = scanner.nextInt();
        scanner.nextLine(); // üres sor beolvasás

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("cars.txt"))) {
            for (int i = 0; i < carCount; i++) {
                System.out.println("Autó #" + (i + 1));

                System.out.print("Márka: ");
                String brand = scanner.nextLine();

                System.out.print("Típus: ");
                String model = scanner.nextLine();

                System.out.print("Szín: ");
                String color = scanner.nextLine();

                System.out.print("Ár: ");
                int price = scanner.nextInt();
                scanner.nextLine(); // üres sor beolvasás

                Car car = new Car(brand, model, color, price);

                String carData = car.getBrand() + ";" + car.getModel() + ";" + car.getColor() + ";" + car.getPrice();
                writer.write(carData);
                writer.newLine();
            }
            System.out.println("Az autók adatai el lettek mentve a cars.txt fájlba.");
        } catch (IOException e) {
            System.out.println("Hiba történt a fájl írása közben: " + e.getMessage());
        }
    }
}

class Car {
    private String brand;
    private String model;
    private String color;
    private int price;

    public Car(String brand, String model, String color, int price) {
        this.brand = brand;
        this.model = model;
        this.color = color;
        this.price = price;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public String getColor() {
        return color;
    }

    public int getPrice() {
        return price;
    }
}
